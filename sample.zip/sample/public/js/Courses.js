$(function () {
    CoursesModule.init();
});

const CoursesModule = (function () {
    const s = {
        table: '#courses-table',
        form: '#courses-form',
        modal: '#course-modal',
        newBtn: '#btnNew',
        saveBtn: '#btnSave',
        modalTitle: '#modal-title',
        title: '#title',
        id: '#id',
    };

    function init() {
        bindEvents();
        loadCourses();
    }

    function bindEvents() {
        $(s.newBtn).on('click', showAddModal);
        $(s.table).on('click', '.edit', handleEdit);
        $(s.table).on('click', '.delete', handleDelete);
        $(s.form).on('submit', submitForm);
        $(s.modal).on('hidden.bs.modal', resetForm);
    }

    function showAddModal(e) {
        e.preventDefault();

        resetForm();
        $(s.modalTitle).text('Add Course');
        $(s.saveBtn).text('Add');
        $(s.modal).modal('show');
    }

    function handleEdit(e) {
        e.preventDefault();

        const id = $(this).data('id');

        $.ajax({
            url: `${base_url}/api/Courses/edit/${id}`,
            type: 'GET',
            dataType: 'json'
        })
            .done((res) => {
                if (!res) return;

                $(s.title).val(res.title);
                $(s.id).val(res.id);

                $(s.modalTitle).text('Edit Course');
                $(s.saveBtn).text('Update');
                $(s.modal).modal('show');
                $(s.title).trigger('focus');
            })
            .fail((xhr) => {
                handleAjaxError(xhr);
            });
    }

    function submitForm(e) {
        e.preventDefault();

        const id = $(s.id).val();
        const fd = new FormData(e.target);

        const url = id
            ? `${base_url}/api/Courses/edit/${id}`
            : `${base_url}/api/Courses/add`;

        $.ajax({
            url: url,
            type: 'POST',
            data: fd,
            processData: false,
            contentType: false,
            dataType: 'json'
        })
            .done((res) => {
                const status = res.status || res.result;

                msgBox(status, res.message);

                if (status === 'success') {
                    loadCourses();
                    $(s.modal).modal('hide');
                    resetForm();
                }
            })
            .fail((xhr) => {
                handleAjaxError(xhr);
            });
    }

    function handleDelete(e) {
        e.preventDefault();

        const id = $(this).data('id');

        isDelete((confirmed) => {
            if (!confirmed) return;

            $.ajax({
                url: `${base_url}/api/Courses/delete/${id}`,
                type: 'DELETE',
                dataType: 'json'
            })
                .done((res) => {
                    const status = res.status || res.result;

                    msgBox(status, res.message);

                    if (status === 'success') {
                        loadCourses();
                    }
                })
                .fail((xhr) => {
                    handleAjaxError(xhr);
                });
        });
    }

    function loadCourses() {
        $(s.table).DataTable({
            responsive: true,
            autoWidth: true,
            destroy: true,
            order: [[0, 'asc']],
            ajax: {
                url: `${base_url}/api/Courses/all`,
                type: 'GET'
            },
            columns: [
                {
                    data: 'title'
                },
                {
                    data: null,
                    className: 'text-center',
                    orderable: false,
                    searchable: false,
                    render: (data) => `
                        <div class="text-center">
                            <a href="#" class="text-success edit"
                               data-id="${data.id}" title="Edit Course">
                                <i class="fa fa-pen"></i>
                            </a> |
                            <a href="#" class="text-danger delete"
                               data-id="${data.id}" title="Delete Course">
                                <i class="fa fa-trash"></i>
                            </a>
                        </div>`
                }
            ]
        });
    }

    function resetForm(e) {
        if (e) {
            e.preventDefault();
        }

        $(s.form).trigger('reset');
        $(s.id).val('');
        $(s.saveBtn).text('Add');
        $(s.modalTitle).text('Add Course');
    }

    return {
        init
    };
})();