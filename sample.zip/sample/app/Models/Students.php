<?php

namespace Models;

use Core\Model;

class Students extends Model
{
    public function find()
    {
        $stmt = $this->db->query(
            'SELECT s.id, c.id, c.title, s.lastname, s.firstname, s.course_id
             FROM students s
             JOIN courses c ON s.course_id = c.id
             ORDER BY s.lastname, s.firstname'
        );

        return $stmt->fetchAll();
    }

    public function findByID($id)
    {
        $stmt = $this->db->prepare(
            'SELECT s.id, c.id, c.title, s.lastname, s.firstname, s.course_id
             FROM students s
             JOIN courses c ON s.course_id = c.id
             WHERE s.id = ?'
        );

        $stmt->execute([$id]);

        return $stmt->fetch() ?: null;
    }

    public function save($data)
    {
        $now = date('Y-m-d H:i:s');

        if (!empty($data['id'])) {
            $stmt = $this->db->prepare(
                'UPDATE students
                 SET lastname = ?, firstname = ?, course_id = ?, modified = ?
                 WHERE id = ?'
            );
            return $stmt->execute([
                $data['lastname'],
                $data['firstname'],
                $data['course_id'],
                $now,
                $data['id'],
            ]);
        }

        $stmt = $this->db->prepare(
            'INSERT INTO students (lastname, firstname, course_id, created, modified)
             VALUES (?, ?, ?, ?, ?)'
        );

        return $stmt->execute([
            $data['lastname'],
            $data['firstname'],
            $data['course_id'],
            $now,
            $now,
        ]);
    }

    public function delete($id): bool
    {
        $stmt = $this->db->prepare(
            'DELETE FROM students WHERE id = ?'
        );

        return $stmt->execute([$id]);
    }
}
            