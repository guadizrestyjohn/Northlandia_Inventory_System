<?php

namespace Models;

use Core\Model;

class Courses extends Model
{
    public function find()
    {
        $stmt = $this->db->query(
            'SELECT id, title
             FROM courses
             ORDER BY title'
        );

        return $stmt->fetchAll();
    }

    public function findByID($id)
    {
        $stmt = $this->db->prepare(
            'SELECT id, title
             FROM courses
             WHERE id = ?'
        );

        $stmt->execute([$id]);

        return $stmt->fetch() ?: null;
    }

    public function save($data)
    {
        $now = date('Y-m-d H:i:s');

        if (!empty($data['id'])) {
           $stmt = $this->db->prepare(
                    'UPDATE courses
                     SET title = ?, modified = ?
                     WHERE id = ?'
                );
                return $stmt->execute([
                    $data['title'],
                    $now,
                    $data['id'],
                ]);

            return $stmt->execute([
                $data['title'],
                $now,
                $data['id'],
            ]);
        }

        $stmt = $this->db->prepare(
            'INSERT INTO courses (title, created, modified)
             VALUES (?, ?, ?)'
        );

        return $stmt->execute([
            $data['title'],
            $now,
            $now,
        ]);
    }

    public function delete($id): bool
    {
        $stmt = $this->db->prepare(
            'DELETE FROM courses WHERE id = ?'
        );

        return $stmt->execute([$id]);
    }
}