<?php

namespace Controllers;

use Core\BaseController;
use Core\Auth;

class CoursesController extends BaseController{

    public function index()
    {
        Auth::requireLogin();
        $this->view('Courses/index', [
            'title' => 'Courses'
        ]);
    }
    
}
