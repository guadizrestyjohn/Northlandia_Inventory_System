<?php
namespace Controllers;

use Core\BaseController;
use Models\Users;
use Core\Auth;

class UsersController extends BaseController
{
    private $Users;

    public function __construct()
    {
        $this->Users = new Users();
    }
    
    public function index()
    {
        Auth::requireLogin();
        $this->view('Users/index', [
            'title' => 'Users'
        ]);
    }

    public function register()
    {   
        $this->view('Users/register', [
            'title' => 'Register',
        ],'auth');

        if ($_SERVER['REQUEST_METHOD'] === 'POST'){
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';

            if ($username === '' || $password === '') {
                $this->json(['status' => 'error', 
                'message' => 'All required fields must be completed.']);
            }

            if (strlen($password) < 4) {
                $this->json(['status' => 'error', 
                'message' => 'Password must contain at least 4 characters.']);
            }

            if ($password !== $confirm) {
                $this->json(['status' => 'error', 
                'message' => 'Passwords do not match.']);
            }

            if ($this->Users->usernameExists($username)) {
                $this->json(['status' => 'error', 
                'message' => 'Username is already taken.']);
            }

            $this->Users->save([
                'username' => $username,
                'password' => $password,
                'role' => 'user',
            ]);

            $_SESSION['success'] = 'Registration successful. You may now log in.';

            $this->redirect(BASE_URL . '/Auth');
        }
        
    }
}
