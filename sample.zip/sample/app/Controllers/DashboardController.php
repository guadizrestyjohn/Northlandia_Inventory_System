<?php
namespace Controllers;

use Core\BaseController;
use Core\Auth;

class DashboardController extends BaseController
{
    public function index(): void
    {
        Auth::requireLogin();
        $this->view('Dashboard/index', [
            'title' => 'Dashboard',
        ]);
    }
}
