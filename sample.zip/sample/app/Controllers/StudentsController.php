<?php

namespace Controllers;

use Core\BaseController;
use Models\Courses;
use Core\Auth;

class StudentsController extends BaseController{

    private $Courses;

    public function __construct()
    {
        $this->Courses = new Courses();
    }

    public function index()
    {
        Auth::requireLogin();
        $this->view('Students/index', [
            'title' => 'Students',
            'courses' => $this->Courses->find()
        ]);
    }
    
}
