<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Student Management</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" id="btnNew">
                <i class="fas fa-plus"></i> New Student
            </button>
        </div>
    </div>

    <div class="card-body">
        <table id="students-table" class="table table-bordered table-striped table-hover w-100">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Course</th>
                    <th class="text-center">Option</th>
                </tr>
            </thead>
        </table>
    </div>
</div>

<div class="modal fade" id="student-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="students-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal-title">Add Student</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="form-group">
                    <label for="lastname">Lastname</label>
                    <input type="text" name="lastname" id="lastname" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="firstname">Firstname</label>
                    <input type="text" name="firstname" id="firstname" class="form-control" required>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="course_id">Course</label>
                        <select name="course_id" id="course_id" class="form-control">
                            <?php foreach ($courses as $course): ?>
                                <option value="<?= $course->id ?>"><?= $course->title ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <input type="hidden" name="id" id="id">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="btnSave">Add</button>
            </div>
        </form>
    </div>
</div>
