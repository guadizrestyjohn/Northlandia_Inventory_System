<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Course Management</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" id="btnNew">
                <i class="fas fa-plus"></i> New Course
            </button>
        </div>
    </div>

    <div class="card-body">
        <table id="courses-table" class="table table-bordered table-striped table-hover w-100">
            <thead>
                <tr>
                    <th>Title</th>
                    <th class="text-center">Option</th>
                </tr>
            </thead>
        </table>
    </div>
</div>

<div class="modal fade" id="course-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="courses-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal-title">Add Course</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" id="title" class="form-control" required>
                </div>
            </div>

            <div class="modal-footer">
                <input type="hidden" name="id" id="id">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="btnSave">Add</button>
            </div>
        </form>
    </div>
</div>
